import { LightningElement, wire } from 'lwc';
import Id from "@salesforce/user/Id";
import retrieveTask from '@salesforce/apex/fetchTasks.retrieveTask';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import updateTask from '@salesforce/apex/fetchTasks.updateTask';

 
const columns = [
    { label: 'Id', fieldName: 'Id' }, 
    { label: 'AssignedTo', fieldName: 'OwnerName', sortable: true  },
    { label: 'Name', fieldName: 'ContactName', sortable: true  },
    { label: 'Due Date', fieldName: 'ActivityDate', sortable: true  },
    { label: 'Subject', fieldName: 'Subject', sortable: true  },
    { label: 'Status', fieldName: 'Status', sortable: true, editable:true},      
];
 
export default class TaskManager extends NavigationMixin(LightningElement)  {
    userId = Id;
    columns = columns;
    items;
    error;
    datacoll;
    saveDraftValue;
    retrievedTask;

    @wire(retrieveTask,{ userRecId: Id })
    wiredTasks(value) {
        this.retrievedTask = value;
        const { data, error} = value;
        if (data) {
            let currentData = [];
            data.forEach((row) => {
                let rowData = {};
                rowData.Id = row.Id;
                rowData.ActivityDate = row.ActivityDate;
                rowData.Subject = row.Subject;
                rowData.Status = row.Status;
                if(row.OwnerId){
                    rowData.OwnerName = row.Owner.Name;
                }
                if(row.WhoId){
                    rowData.ContactName = row.Who.Name; 
                }
                
                currentData.push(rowData);
            });

            this.items = currentData;
            this.columns = columns;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.items = undefined;
            this.showToast(this.error, 'Error', 'Error'); //show toast for error
        }
    }
 
    handleSave(event){
        const updatedfield = event.detail.draftValues;
            this.saveDraftValue = event.detail.draftValues;
            updateTask({tskObject :  this.saveDraftValue})
            .then( result =>{
                 this.dispatchEvent(
                    new ShowToastEvent({
                        title: result,
                        message: result,
                        variant: 'success'
                    })
                );
                this.saveDraftValue = undefined;
                refreshApex( this.retrievedTask);
            })
            .catch(error=>{
                console.error("err:"+JSON.stringify(error))               
            })             
        }
 
    showToast(message, variant, title) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }
}