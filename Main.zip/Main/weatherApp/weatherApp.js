import { LightningElement,api,wire } from 'lwc';
import WEATHER_ICONS from '@salesforce/resourceUrl/weatherAppIcons';

// Importing the class and method
import GET_WEATHER_DETAILS from '@salesforce/apex/weatherAppController.getWeatherDetails';

const API_KEY='57901c899d18f2711e9009301e5c816b'
export default class WeatherApp extends LightningElement {
  @api recordId;
    // Defining the weather icons using imported resources
    clearIcon=WEATHER_ICONS+'/animated/day.svg'
    cloudIcon=WEATHER_ICONS+'/animated/cloudy.svg'
    dropletIcon=WEATHER_ICONS+'/animated/rainy-1.svg'
    hazeIcon=WEATHER_ICONS+'/animated/snowy-1.svg'
    mapIcon=WEATHER_ICONS+'/animated/weather.svg'
    rainIcon=WEATHER_ICONS+'/animated/rainy-5.svg'
    snowIcon=WEATHER_ICONS+'/animated/snowy-2.svg'
    stormIcon=WEATHER_ICONS+'/animated/thunder.svg'
    thermometerIcon=WEATHER_ICONS+'/animated/thermometer.svg'

  isError = false
  loadingText
  response
  weatherIcon

  connectedCallback(){
    this.fetchData();
  }

  fetchData(){

    // Resetting error status and loading text
    this.isError = false
    this.loadingText = 'Fetching weather details...'
 
    GET_WEATHER_DETAILS({input:this.recordId}).then(result=>{

        this.weatherDetails(JSON.parse(result))
    }).catch((error)=>{
               console.error(error)
               this.response=null
               this.loadingText = "Something went wrong"
               this.isError = true
             }) 
}

  weatherDetails(info){

    if(info.cod === "404"){
      this.isError = true 
      this.loadingText = `${this.cityName} isn't a valid city name`
    } 
    else 
    {
      // Extracting weather data and storing it in response variable
      this.loadingText = ''
      this.isError=false

      const city=info.name
      const country=info.sys.country
      const {description,id}=info.weather[0]
      const {temp,feels_like,humidity}=info.main
      this.response={
        city:city,
        temprature:Math.floor(temp),
        description:description,
        location:`${city},${country}`,
        feels_like:Math.floor(feels_like),
        humidity:`${humidity}%`
      }
    }
  }

}